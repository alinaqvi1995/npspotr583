<?php $__env->startSection('title', 'Get Car Shipping Quote | ShipA1'); ?>
<?php $__env->startSection('meta_description',
    'Experience seamless car shipping with Shipa Car Transport. Get an instant quote,
    nationwide coverage, and transparent pricing. Trust us for swift and secure vehicle transportation.'); ?>
<?php $__env->startSection('content'); ?>

    <style>
        /* Error styling */
        .error {
            border: 2px solid red;
        }

        .make-dropdown {
            max-height: 200px;
            /* Set the maximum height */
            overflow-y: auto;
            /* Enable vertical scrolling */
        }

        .dropdown-item {
            white-space: nowrap;
            /* Prevent text wrapping */
        }

        /* Ensure the dropdown menu does not push the page */
        .model-dropdown {
            max-height: 200px;
            /* Adjust based on your design */
            overflow-y: auto;
            position: absolute;
            /* Ensures dropdown is properly positioned */
            z-index: 1000;
            /* Ensures dropdown appears above other content */
        }

        /* Adjust this if needed to prevent overflow issues */
        .input-form.tj-select {
            position: relative;
        }
    </style>
    <!--========== breadcrumb Start ==============-->
    <section class="breadcrumb-wrapper" data-bg-image="<?php echo e(asset('frontend/images/banner/all-cover-banner.webp')); ?>">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-content">
                        <h1 class="breadcrumb-title text-center">Vehicle - Car</h1>
                        <div class="breadcrumb-link">
                            <span>
                                <a href="<?php echo e(route('welcome')); ?>">
                                    <span>Home</span>
                                </a>
                            </span>
                            >
                            <span>
                                <span> Vehicle - Car</span>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--========== breadcrumb End ==============-->
    <section class="tj-choose-us-section">
        <div class="container-flude">
            <div class="row">
                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                    <div class="alert alert-error">
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>
                <div class="col-lg-12" data-sal="slide-down" data-sal-duration="800">
                    <div class="tj-input-form" data-bg-image="">
                        <h4 class="title text-center">Instant Car Shipping Quote!</h4>
                        <form action="<?php echo e(route('submit.quote')); ?>" method="post" class="rd-mailform validate-form"
                            id="calculatePriceFrom" novalidate data-parsley-validate data-parsley-errors-messages-disabled
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            <input type="hidden" name="vehicle_opt" value="vehicle" hidden>
                            <input type="hidden" name="car_type" value="1" hidden>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="input-form">
                                        <label class="d-block"> Your Name:</label>
                                        <input type="text" id="name" name="name" placeholder="Full Name"
                                            required="" />
                                        <small id="errName" class="err-style"></small>
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="input-form">
                                        <label class="d-block">Phone:</label>
                                        <input type="tel" id="phone" name="phone" class="ophone"
                                            placeholder="Phone Number" required="" />
                                        <small id="errPhone" class="err-style"></small>
                                        <input type="hidden" name="country_code" id="country_code" />
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="input-form">
                                        <label class="d-block"> Email Address:</label>
                                        <input type="email" id="email" name="email" placeholder="Your Email Address"
                                            required="" />
                                        <small id="errEmail" class="err-style"></small>
                                    </div>
                                </div>
                            </div>
                            <div class="row mt-0">
                                <div class="col-md-6">
                                    <div class="input-form">
                                        <label class="d-block"> Pickup Location:</label>
                                        <input type="text" id="pickup-location" name="origin"
                                            placeholder="Ex: 90005 Or Los Angeles" required="" />
                                        <small id="errOLoc" class="err-loc"></small>
                                        <ul class="suggestions suggestionsTwo"></ul>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="input-form">
                                        <label class="d-block"> Delivery Location:</label>
                                        <input type="text" id="delivery-location" name="destination"
                                            placeholder="Ex: 90005 Or Los Angeles" required="" />
                                        <small id="errDLoc" class="err-loc"></small>
                                        <ul class="suggestions suggestionsTwo"></ul>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Initial Vehicle Information -->
                            <div class="vehicle-info">
                                <div class="row select-bm">
                                    <div class="col-md-12 text-center">
                                        <h4 class="text-white">Car Information</h4>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="input-form tj-select">
                                            <label>Year</label>
                                            <div class="dropdown">
                                                <input class="form-control dropdown-toggle year" type="text"
                                                    name="year[]" id="year" placeholder="Select Year"
                                                    data-bs-toggle="dropdown" aria-expanded="false" required>
                                                <ul class="dropdown-menu year-dropdown" aria-labelledby="year">
                                                    <li><a class="dropdown-item">Select Year</a></li>
                                                    <?php
                                                        $currentYear = date('Y');
                                                        for ($year = $currentYear; $year >= 1936; $year--) {
                                                            echo "<li><a class='dropdown-item' data-value='$year'>$year</a></li>";
                                                        }
                                                    ?>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-4">
                                        <div class="input-form tj-select">
                                            <label>Make</label>
                                            <div class="dropdown">
                                                <input class="form-control dropdown-toggle make" name="make[]" required
                                                    type="text" id="make" placeholder="Select Make"
                                                    data-bs-toggle="dropdown" aria-expanded="false">
                                                <ul class="dropdown-menu make-dropdown" style=""
                                                    aria-labelledby="make">
                                                    <li><a class="dropdown-item">Select Make</a></li>
                                                    <?php $__currentLoopData = $makes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $make): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li><a class="dropdown-item"
                                                                data-value="<?php echo e($make->make); ?>"><?php echo e($make->make); ?></a>
                                                        </li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-4">
                                        <div class="input-form tj-select model-div">
                                            <label>Model</label>
                                            <div class="dropdown">
                                                <input class="form-control dropdown-toggle model-input" name="model[]"
                                                    type="text" id="model" required placeholder="Select Model"
                                                    data-bs-toggle="dropdown" aria-expanded="false">
                                                <ul class="dropdown-menu model-dropdown" style=""
                                                    aria-labelledby="model">
                                                    <li><a class="dropdown-item" href="#">Select Model</a></li>
                                                    <!-- Options filled by JavaScript -->
                                                </ul>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                            
                            
                            
                            
                            
                            
                            
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <div class="form-group" style="line-height:23px;">
                                        <label for="trailer_type" class="text-white">Select Trailer Type</label>
                                        <select class="form-control" id="trailer_type" name="trailer_type">
                                            <option value="1" selected>Open Trailer</option>
                                            <option value="2">Enclosed Trailer</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="condition" class="text-white">Condition</label>
                                        <select class="form-control" id="condition" name="condition[]">
                                            <option value="1" selected>Running</option>
                                            <option value="2">Non Running</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <a id="addVehicleBtn" class="add-car">
                                <i class="fa fa-plus"> Add Vehicle </i>
                            </a>
                            <div id="vehicles-container">
                            </div>
                            
                            <div class="row">
                                <div class="input-form mt-1">
                                    <label class="d-block text-white"> Image:</label>
                                    <input class="form-control image_input" name="image[]" type="file"
                                        accept="image/*" multiple onchange="previewImages(event)">
                                    <div class="image-preview-container" id="imagePreviewContainer"></div>
                                    <!-- <input class="form-control image_input" type="file" id="image" name="image" onchange="previewImage(event)" />
                                                                                                                                                                        <img id="imagePreview" src="#" alt="Image Preview" style="display: none; max-width: 100px; max-height: 100px; margin-top: 10px;"> -->
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <input class="form-check-input " type="checkbox" id="modification"
                                            name="modification" value="1" />
                                        <label class="form-check-label text-white ms-4" for="modification">
                                            Modified?</label>
                                    </div>
                                    <div class="input-form div-modify_info" style="display: none;">
                                        <label class="d-block"> Modification Information:</label>
                                        <input class="" type="text" id="c" name="modify_info"
                                            placeholder="Enter Modification Information" />
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="available_at_auction"
                                            name="available_at_auction" value="1" />
                                        <label class="form-check-label text-white" for="available_at_auction"> Available
                                            at
                                            Auction?</label>
                                    </div>
                                    <div class="input-form div-link mt-3" style="display: none;">
                                        <label class="d-block"> Enter Link:</label>
                                        <input class="form-control" type="url" id="link" name="link"
                                            placeholder="Enter Link" />
                                    </div>
                                </div>
                            </div>
                            <div class="tj-theme-button text-center mt-3">
                                <button class="tj-submit-btn" type="submit" value="submit">
                                    Calculate Price <i class="fa-light fa-arrow-right"></i>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extraScript'); ?>
    <!-- Include Selectize CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.6/css/selectize.min.css" rel="stylesheet" />
    <!-- Include jQuery and Selectize JS -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.6/js/standalone/selectize.min.js"></script>
    <script>
        // $(document).ready(function() {
        //         $('select').niceSelect(); // Initialize nice-select
        //     });
        $(document).ready(function() {
            function addNewVehicle() {
                var newVehicleHtml =
                    `
                <div class="vehicle-info">
                <div class="row select-bm">
                    <!-- Bin icon for deleting vehicle -->
                    <span class="delete-vehicle"><i class="fa fa-trash" style="float: right; margin-top: 0px; color: red;"></i></span>
                    <div class="col-md-4">
                        <div class="input-form tj-select">
                            <label>Year</label>
                            <div class="dropdown">
                                <input class="form-control dropdown-toggle year" type="text"
                                    name="year[]" id="year" placeholder="Select Year"
                                    data-bs-toggle="dropdown" aria-expanded="false" required>
                                <ul class="dropdown-menu year-dropdown" aria-labelledby="year">
                                    <li><a class="dropdown-item">Select Year</a></li>`;
                var currentYear = <?php echo e(date('Y')); ?>;
                for (var year = currentYear; year >= 1936; year--) {
                    newVehicleHtml += `<li><a class='dropdown-item' data-value='${year}'>${year}</a></li>`;
                }
                newVehicleHtml += `
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="input-form tj-select">
                            <label>Make</label>
                            <div class="dropdown">
                                <input class="form-control dropdown-toggle make" name="make[]" type="text" id="make" placeholder="Select Make" data-bs-toggle="dropdown" aria-expanded="false">
                                <ul class="dropdown-menu make-dropdown" aria-labelledby="make">
                                    <li><a class="dropdown-item" >Select Make</a></li>`;
                <?php $__currentLoopData = $makes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $make): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    newVehicleHtml +=
                        `<li><a class="dropdown-item"  data-value="<?php echo e($make->make); ?>"><?php echo e($make->make); ?></a></li>`;
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                newVehicleHtml += `
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="input-form tj-select model-div">
                            <label>Model</label>
                            <select class="nice-select model" name="model[]" id="model" required>
                                <!-- Options will be filled by JavaScript -->
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="condition" class="text-white">Condition</label>
                            <select class="nice-select" id="condition" name="condition[]">
                                <option value="1" selected>Running</option>
                                <option value="2">Non Running</option>
                            </select>
                        </div>
                    </div>
                </div>
                </div>
            `;
                $('#vehicles-container').append(newVehicleHtml);
            }

            $('#addVehicleBtn').click(function() {
                addNewVehicle();
            });

            $(document).on('click', '.delete-vehicle', function() {
                $(this).closest('.vehicle-info').remove();
            });

            $(document).on('click', '.make-dropdown .dropdown-item', function() {
                var make = $(this).data('value');
                $(this).closest('.dropdown').find('.form-control').val(make).end()
                    .find('.dropdown-menu').removeClass('show');
                var vehicleInfo = $(this).closest('.vehicle-info');
                var year = vehicleInfo.find('.year').val();
                if (year && make) {
                    getModel(year, make, vehicleInfo);
                }
            });
            // $(document).on('change', '.year, .make', function() {
            //     var year = $(this).closest('.vehicle-info').find('.year').val();
            //     var makeId = $(this).closest('.vehicle-info').find('.make').val();
            //     alert(makeId);
            //     var vehicleInfo = $(this).closest('.vehicle-info');
            //     if (year && makeId) {
            //         getModel(year, makeId, vehicleInfo);
            //     }
            // });
            $(document).on('click', '.year-dropdown .dropdown-item', function() {
                console.log('okokok');
                var selectedYear = $(this).data('value');
                var vehicleInfo = $(this).closest(
                    '.vehicle-info');
                vehicleInfo.find('.year').val(
                    selectedYear);
            });

            $(document).on('click', '.year, .make', function() {
                var year = $(this).closest('.vehicle-info').find('.year').val();
                var makeId = $(this).closest('.vehicle-info').find('.make').val();
                // alert(makeId);
                var vehicleInfo = $(this).closest('.vehicle-info');
                if (year && makeId) {
                    getModel(year, makeId, vehicleInfo);
                }
            });

            function getModel(year, makeId, vehicleInfo) {
                $.ajax({
                    url: "<?php echo e(route('get.models')); ?>",
                    method: 'GET',
                    data: {
                        year: year,
                        make: makeId
                    },
                    success: function(response) {
                        var modelDropdown = vehicleInfo.find('.model-dropdown');
                        var modelInput = vehicleInfo.find('.model-input');
                        var modelSelect = vehicleInfo.find('.model'); // Standard <select> element

                        // Update custom dropdown
                        if (modelDropdown.length && modelInput.length) {
                            modelDropdown.empty();
                            modelDropdown.append(
                                '<li><a class="dropdown-item" data-value="">Select Model</a></li>');

                            $.each(response, function(index, model) {
                                modelDropdown.append(
                                    '<li><a class="dropdown-item" data-value="' + model +
                                    '">' + model + '</a></li>');
                            });

                            modelInput.on('focus', function() {
                                modelSelect.empty(); // Clear the <select> options
                                modelSelect.append(
                                    '<option value="">Select Model</option>'
                                ); // Add default option
                                modelDropdown.show();
                            });

                            modelInput.on('input', function() {
                                var searchTerm = $(this).val().toLowerCase();
                                modelDropdown.find('li').each(function() {
                                    var itemText = $(this).text().toLowerCase();
                                    if (itemText.indexOf(searchTerm) !== -1 ||
                                        searchTerm === '') {
                                        $(this).show();
                                    } else {
                                        $(this).hide();
                                    }
                                });
                            });

                            modelDropdown.on('click', 'a.dropdown-item', function(e) {

                                e.preventDefault(); // Prevent default anchor behavior
                                var selectedText = $(this).text();
                                var selectedValue = $(this).data('value');

                                modelInput.val(
                                    selectedText); // Set the selected text in modelInput
                                modelDropdown.hide(); // Hide the custom dropdown

                                modelSelect.empty(); // Clear the <select> options
                                modelSelect.append('<option value="' + selectedValue + '">' +
                                    selectedText + '</option>');
                                modelSelect.val(
                                    selectedValue
                                ); // Set the selected value in the select dropdown
                            });

                            $(document).on('click', function(e) {
                                if (!modelInput.is(e.target) && !modelDropdown.is(e.target) &&
                                    modelDropdown.has(e.target).length === 0) {
                                    modelDropdown.hide();
                                }
                            });
                        }

                        // Handle standard <select> dropdown
                        if (modelSelect.length) {
                            modelSelect.empty(); // Clear any existing options
                            modelSelect.append(
                                '<option value="">Select Model</option>'); // Add default option

                            $.each(response, function(index, model) {
                                modelSelect.append('<option value="' + model + '">' + model +
                                    '</option>');
                            });

                            modelSelect.on('change', function() {

                                var selectedModel = $(this).val();
                                // Optional: Sync custom input when user selects from <select>
                                modelInput.val(modelSelect.find('option:selected').text());
                            });
                        }
                    },
                    error: function(xhr) {
                        console.log(xhr.responseText);
                    }
                });
            }

            $(document).on('input', '.dropdown-toggle', function() {
                var input = $(this).val().toLowerCase();
                // console.log('ttt', text);
                $(this).siblings('.dropdown-menu').find('.dropdown-item').each(function() {
                    var text = $(this).text().toLowerCase();
                    $(this).toggle(text.indexOf(input) > -1);
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\bridgeway\resources\views\site\quote\car.blade.php ENDPATH**/ ?>