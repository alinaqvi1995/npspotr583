
<?php $__env->startSection('title', 'Services'); ?>
<?php $__env->startSection('content'); ?>

<!--========== breadcrumb Start ==============-->
    <section class="breadcrumb-wrapper" data-bg-image="web-assets/images/banner/breadcrumb.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-content">
                        <h1 class="breadcrumb-title text-center">Service Page</h1>
                        <div class="breadcrumb-link">
                            <span>
                                <a href="index.html">
                                    <span>Home</span>
                                </a>
                            </span>
                            >
                            <span>
                                <span> Service</span>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<!--========== breadcrumb End ==============-->

<!--========== Service Section Start ==============-->
    <section class="tj-service-section-four tj-service-page">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="tj-section-heading text-center">
                        <span class="sub-title active-shape"> What We Do</span>
                        <h2 class="title">Logistic & Transport</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-6" data-sal="slide-up" data-sal-duration="800" data-sal-delay="300">
                    <div class="service-item-three">
                        <div class="service-image">
                            <img src="web-assets/images/service/service-8.jpg" alt="Image" />
                        </div>
                        <div class="service-content">
                            <div class="service-icon">
                                <i class="flaticon-air-freight"></i>
                            </div>
                            <h4><a class="title" href="service-details.html"> Air Freight Service</a></h4>
                            <p>Long established fact that reader will be distracted by the</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6" data-sal="slide-up" data-sal-duration="800" data-sal-delay="400">
                    <div class="service-item-three">
                        <div class="service-image">
                            <img src="web-assets/images/service/service-9.jpg" alt="Image" />
                        </div>
                        <div class="service-content">
                            <div class="service-icon">
                                <i class="flaticon-cargo-ship-1"></i>
                            </div>
                            <h4><a class="title" href="service-details.html"> Ocean Freight</a></h4>
                            <p>Long established fact that reader will be distracted by the</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6" data-sal="slide-up" data-sal-duration="800" data-sal-delay="500">
                    <div class="service-item-three">
                        <div class="service-image">
                            <img src="web-assets/images/service/service-10.jpg" alt="Image" />
                        </div>
                        <div class="service-content">
                            <div class="service-icon">
                                <i class="flaticon-delivery-van"></i>
                            </div>
                            <h4><a class="title" href="service-details.html"> Road Transport</a></h4>
                            <p>Long established fact that reader will be distracted by the</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6" data-sal="slide-up" data-sal-duration="800" data-sal-delay="600">
                    <div class="service-item-three">
                        <div class="service-image">
                            <img src="web-assets/images/service/service-16.jpg" alt="Image" />
                        </div>
                        <div class="service-content">
                            <div class="service-icon">
                                <i class="flaticon-air-freight"></i>
                            </div>
                            <h4><a class="title" href="service-details.html"> Third Party Logistics</a></h4>
                            <p>Long established fact that reader will be distracted by the</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6" data-sal="slide-up" data-sal-duration="800" data-sal-delay="700">
                    <div class="service-item-three">
                        <div class="service-image">
                            <img src="web-assets/images/service/service-17.jpg" alt="Image" />
                        </div>
                        <div class="service-content">
                            <div class="service-icon">
                                <i class="flaticon-cargo-ship-1"></i>
                            </div>
                            <h4><a class="title" href="service-details.html"> Distribution Center</a></h4>
                            <p>Long established fact that reader will be distracted by the</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6" data-sal="slide-up" data-sal-duration="800" data-sal-delay="800">
                    <div class="service-item-three">
                        <div class="service-image">
                            <img src="web-assets/images/service/service-18.jpg" alt="Image" />
                        </div>
                        <div class="service-content">
                            <div class="service-icon">
                                <i class="flaticon-delivery-van"></i>
                            </div>
                            <h4><a class="title" href="service-details.html"> Train Transportation</a></h4>
                            <p>Long established fact that reader will be distracted by the</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<!--========== Service Section End ==============-->

<!--=========== Feature Section Start =========-->
    <section class="tj-choose-us-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-6" data-sal="slide-left" data-sal-duration="800">
                    <div class="choose-us-content-1">
                        <div class="tj-section-heading">
                            <span class="sub-title active-shape2"> Why Choose Us</span>
                            <h2 class="title">We are the Future of Cargo & Logistics</h2>
                            <p class="desc">
                                Quisque dignissim enim diam, eget pulvinar ex viverra id. Nulla a lobortis lectus,
                                id volutpat magna. Morbi consequat porttitor
                            </p>
                        </div>
                        <div class="row">
                            <div class="col-md-4 col-sm-4 col-6">
                                <div class="tj-icon-box3 text-center">
                                    <i class="flaticon flaticon-courier"></i>
                                    <h6 class="title">Optimized Cost</h6>
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-4 col-6">
                                <div class="tj-icon-box3 text-center">
                                    <i class="flaticon flaticon-cargo"></i>
                                    <h6 class="title">Delivery on Time</h6>
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-4 col-6">
                                <div class="tj-icon-box3 text-center">
                                    <i class="flaticon flaticon-agreement"></i>
                                    <h6 class="title">Safety & Reliability</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6" data-sal="slide-right" data-sal-duration="800">
                    <div class="tj-input-form" data-bg-image="web-assets/images/banner/form-shape.png">
                        <h4 class="title">Request a Quote</h4>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="input-form">
                                    <label class="d-block"> Your Name:</label>
                                    <input
                                        type="text"
                                        id="yourName"
                                        name="name"
                                        placeholder="First Name"
                                        required=""
                                    />
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="input-form">
                                    <label class="d-block"> Your Email:</label>
                                    <input
                                        type="text"
                                        id="yourEmail"
                                        name="name"
                                        placeholder=" Email"
                                        required=""
                                    />
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="input-form">
                                    <label class="d-block"> Your Phone:</label>
                                    <input type="text" id="yourPhone" name="name" placeholder="Phone" required="" />
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="tj-input-range">
                                    <div class="d-flex flex-wrap justify-content-between">
                                        <label> Distance (miles):</label>
                                        <output class="output"></output>
                                    </div>
                                    <input
                                        class="tj-range-1"
                                        type="range"
                                        min="400"
                                        max="7000"
                                        step="10"
                                        value="800"
                                    />
                                </div>
                            </div>
                        </div>
                        <div class="row select-bm">
                            <div class="col-md-6">
                                <div class="input-form tj-select">
                                    <label> Freight Type:</label>
                                    <select class="nice-select">
                                        <option value="2">Select</option>
                                        <option value="1" disabled>Optimized Cost</option>
                                        <option value="2">Delivery on Time</option>
                                        <option value="3">Cargo</option>
                                        <option value="4">Safety & Reliability</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="input-form tj-select">
                                    <label> Load:</label>
                                    <select class="nice-select">
                                        <option value="2">Select</option>
                                        <option value="1" disabled>Optimized Cost</option>
                                        <option value="2">Delivery on Time</option>
                                        <option value="3">Cargo</option>
                                        <option value="4">Safety & Reliability</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="tj-theme-button">
                            <button class="tj-submit-btn" type="submit" value="submit">
                                Submit Now <i class="fa-light fa-arrow-right"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<!--=========== Feature Section End =========-->

<!--=========== Team Section Start =========-->
    <section class="tj-team-section-two">
        <div class="container">
            <div class="row">
                <div class="tj-section-heading text-center">
                    <span class="sub-title active-shape"> Our Workers</span>
                    <h2 class="title">Our Delivery Team</h2>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-6" data-sal="slide-up" data-sal-duration="800" data-sal-delay="300">
                    <div class="tj-team-item-two">
                        <div class="image-box">
                            <img class="circule-1" src="web-assets/images/team/team-1.png" alt="Image" />
                        </div>
                        <div class="team-content text-center">
                            <h4><a class="title-link" href="team-details.html">Mike Hardson</a></h4>
                            <span class="sub-title"> Manager</span>
                        </div>
                        <div class="social-icon-box">
                            <ul class="social-icon">
                                <li>
                                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                                </li>
                                <li>
                                    <a href="#"><i class="fab fa-linkedin-in"></i></a>
                                </li>
                                <li>
                                    <a href="#"><i class="fab fa-twitter"></i></a>
                                </li>
                                <li>
                                    <a href="#"><i class="fab fa-instagram"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6" data-sal="slide-up" data-sal-duration="800" data-sal-delay="400">
                    <div class="tj-team-item-two">
                        <div class="image-box">
                            <img class="circule-1" src="web-assets/images/team/team-2.png" alt="Image" />
                        </div>
                        <div class="team-content text-center">
                            <h4><a class="title-link" href="team-details.html">David Cooper</a></h4>
                            <span class="sub-title"> Co Founder</span>
                        </div>
                        <div class="social-icon-box">
                            <ul class="social-icon">
                                <li>
                                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                                </li>
                                <li>
                                    <a href="#"><i class="fab fa-linkedin-in"></i></a>
                                </li>
                                <li>
                                    <a href="#"><i class="fab fa-twitter"></i></a>
                                </li>
                                <li>
                                    <a href="#"><i class="fab fa-instagram"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6" data-sal="slide-up" data-sal-duration="800" data-sal-delay="500">
                    <div class="tj-team-item-two">
                        <div class="image-box">
                            <img src="web-assets/images/team/team-3.png" alt="Image" />
                        </div>
                        <div class="team-content text-center">
                            <h4><a class="title-link" href="team-details.html">Lucas Damian</a></h4>
                            <span class="sub-title"> Architect</span>
                        </div>
                        <div class="social-icon-box">
                            <ul class="social-icon">
                                <li>
                                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                                </li>
                                <li>
                                    <a href="#"><i class="fab fa-linkedin-in"></i></a>
                                </li>
                                <li>
                                    <a href="#"><i class="fab fa-twitter"></i></a>
                                </li>
                                <li>
                                    <a href="#"><i class="fab fa-instagram"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<!--=========== Team Section End =========-->

<!--=========== Newsletter Section Start =========-->
    <section class="tj-subscribe-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div
                        class="subscribe-content-box d-flex align-items-center justify-content-between"
                        data-bg-image="web-assets/images/banner/subscribe.png"
                    >
                        <div class="subscribe-content d-flex align-items-center">
                            <div class="mail-icon">
                                <img src="web-assets/images/icon/email.svg" alt="Icon" />
                            </div>
                            <div class="subscribe-title">
                                <h3 class="title">Subscribe Our Newslatter</h3>
                            </div>
                        </div>
                        <div class="subscribe-form d-flex align-items-center">
                            <div class="subscribe-input">
                                <input
                                    type="text"
                                    id="email"
                                    name="emailAddress"
                                    placeholder="Email Address"
                                    required=""
                                />
                            </div>
                            <div class="tj-theme-button">
                                <button class="tj-submit-btn" type="submit" value="submit">
                                    Submit Now <i class="fa-light fa-arrow-right"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<!--=========== Newsletter Section End =========-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\bridgeway\resources\views\site\services\index.blade.php ENDPATH**/ ?>