@extends('layouts.guest')

@section('title', 'Home')

@section('content')

@endsection